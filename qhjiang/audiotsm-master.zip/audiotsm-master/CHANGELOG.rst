Changelog
=========

`0.1.2`_ (2017-09-21)
---------------------

- added phase vocoder procedure


`0.1.1`_ (2017-09-20)
---------------------

- added GStreamer plugins

`0.1.0`_ (2017-09-11)
---------------------

- added OLA and WSOLA procedures

.. _0.1.0: https://github.com/Muges/audiotsm/releases/tag/v0.1.0
.. _0.1.1: https://github.com/Muges/audiotsm/compare/v0.1.0...v0.1.1
.. _0.1.2: https://github.com/Muges/audiotsm/compare/v0.1.1...v0.1.2
