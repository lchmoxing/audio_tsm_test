This directory contains a small subset of the version 0.4.1 of the spectre_ CSS framework, released under MIT license by Yan Zhu.

.. _spectre: https://github.com/picturepan2/spectre
