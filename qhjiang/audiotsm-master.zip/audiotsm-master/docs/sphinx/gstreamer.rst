Gstreamer plugins
=================

.. automodule:: audiotsm.gstreamer


OLA
-----

.. automodule:: audiotsm.gstreamer.ola
    :members:
    :show-inheritance:

WSOLA
-----

.. automodule:: audiotsm.gstreamer.wsola
    :members:
    :show-inheritance:

Phase Vocoder
-------------

.. automodule:: audiotsm.gstreamer.phasevocoder
    :members:
    :show-inheritance:
