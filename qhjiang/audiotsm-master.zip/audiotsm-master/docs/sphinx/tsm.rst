Time-Scale Modification
=======================

Time-Scale Modification procedures
----------------------------------

.. automodule:: audiotsm

TSM Object
----------

.. automodule:: audiotsm.base.tsm
    :members:
