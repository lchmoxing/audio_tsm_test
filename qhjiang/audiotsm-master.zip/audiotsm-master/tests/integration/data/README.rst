beethoven
   The beethoven directory contains an extract from a recording of Beethoven's
   Piano Sonata No. 14, released by `Bernd Krueger`_ under the cc-by-sa
   License.

brad-sucks
   The brad-sucks directory contains extracts from songs of the album `Out of
   It`_, released by Brad Sucks under cc-by-sa license. 

tsmtoolbox
   The tsmtoolbox directory contains audio files taken from the `TSMToolbox
   examples`_, a MATLAB TSM library. The audio files should be short enough to
   fall under fair use.

.. _Bernd Krueger: http://www.piano-midi.de/
.. _Out of It: http://www.bradsucks.net/albums/out_of_it/
.. _TSMToolbox examples: https://www.audiolabs-erlangen.de/resources/MIR/TSMtoolbox/
