import sys
sys.path.append(".")
import logging
logging.basicConfig(level=logging.INFO)

__all__ = ["Test_RecogniseFile"]
logging.warning('Unit test imported.')